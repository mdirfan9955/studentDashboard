
/* =================================
   1. LOCAL STORAGE FUNCTIONS
================================= */

// Get saved data from Local Storage
function getData(key, defaultValue) {
    const data = localStorage.getItem(key);

    return data ? JSON.parse(data) : defaultValue;
}

// Save data in Local Storage
function saveData(key, data) {
    localStorage.setItem(key, JSON.stringify(data));
}

// Generate unique ID
function generateId() {
    return Date.now() + Math.floor(Math.random() * 1000);
}

// Prevent HTML injection
function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, char => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    })[char]);
}


/* =================================
   2. STUDENT PROFILE
================================= */

let student = getData("studentProfile", {
    name: "Md Irfan",
    course: "Diploma in Information Technology",
    semester: "5th Semester",
    roll: "Not Added",
    email: "Not Added"
});

// Display student information
function displayProfile() {

    document.querySelector(".student-info h3").textContent =
        student.name;

    document.querySelector(".student-info .profile-image")
        .textContent = student.name.split(" ").map(n => n[0]).join("").slice(0, 2);

    document.querySelector(".header-profile").textContent =
        student.name.split(" ").map(n => n[0]).join("").slice(0, 2);

    document.querySelector(".student-info p:nth-of-type(1)")
        .textContent = student.course;

    document.querySelector(".student-info p:nth-of-type(2)")
        .textContent = student.semester;

    document.querySelector("#welcomeName");
    
    const profileDetails = document.querySelector("#profile");

    const paragraphs = profileDetails.querySelectorAll(".content-card p");

    paragraphs[0].innerHTML =
        "<strong>Name:</strong> " + escapeHTML(student.name);

    paragraphs[1].innerHTML =
        "<strong>Course:</strong> " + escapeHTML(student.course);

    paragraphs[2].innerHTML =
        "<strong>Semester:</strong> " + escapeHTML(student.semester);

    paragraphs[3].innerHTML =
        "<strong>Roll Number:</strong> " + escapeHTML(student.roll);

    paragraphs[4].innerHTML =
        "<strong>Email:</strong> " + escapeHTML(student.email);
}


// Edit student profile
document.getElementById("editProfileBtn")
.addEventListener("click", function () {

    let name = prompt("Enter your name:", student.name);

    if (name === null) return;
    if (!name.trim()) return alert("Name cannot be empty.");

    let course = prompt("Enter your course:", student.course);

    if (course === null) return;

    let semester = prompt("Enter your semester:", student.semester);

    if (semester === null) return;

    let roll = prompt("Enter your roll number:", student.roll);

    if (roll === null) return;

    let email = prompt("Enter your email:", student.email);

    if (email === null) return;

    student = {
        name: name.trim(),
        course: course.trim(),
        semester: semester.trim(),
        roll: roll.trim(),
        email: email.trim()
    };

    saveData("studentProfile", student);

    displayProfile();

    alert("Profile updated successfully!");

});


/* =================================
   3. ATTENDANCE
================================= */

const attendanceData = [
    { subject: "Java Programming", percentage: 90 },
    { subject: "Web Technology", percentage: 85 },
    { subject: "AI & ML", percentage: 88 },
    { subject: "Internet of Things", percentage: 82 },
    { subject: "OOAD", percentage: 86 }
];

function displayAttendance() {

    const attendanceList = document.getElementById("attendanceList");

    attendanceList.innerHTML = attendanceData.map(item => `
        <div class="attendance-item">

            <strong>${escapeHTML(item.subject)}</strong>

            <span>${item.percentage}%</span>

            <div class="progress-bar">
                <div style="width:${item.percentage}%"></div>
            </div>

        </div>
    `).join("");

    let total = attendanceData.reduce(
        (sum, item) => sum + item.percentage, 0
    );

    document.getElementById("attendancePercentage")
        .textContent = Math.round(total / attendanceData.length) + "%";
}


/* =================================
   4. TIMETABLE
================================= */

const timetable = [
    ["Monday", "09:30 AM", "Web Technology"],
    ["Monday", "10:30 AM", "Java Programming"],
    ["Tuesday", "09:30 AM", "AI & ML"],
    ["Tuesday", "10:30 AM", "Internet of Things"],
    ["Wednesday", "09:30 AM", "OOAD"],
    ["Wednesday", "10:30 AM", "Web Technology"],
    ["Thursday", "09:30 AM", "Java Programming"],
    ["Thursday", "10:30 AM", "AI & ML"],
    ["Friday", "09:30 AM", "Internet of Things"],
    ["Friday", "10:30 AM", "OOAD"]
];

function displayTimetable() {

    const tbody = document.getElementById("timetableBody");

    tbody.innerHTML = timetable.map(item => `
        <tr>
            <td>${item[0]}</td>
            <td>${item[1]}</td>
            <td>${item[2]}</td>
        </tr>
    `).join("");

}


/* =================================
   5. ASSIGNMENTS
================================= */

let assignments = getData("assignments", []);

const assignmentForm = document.getElementById("assignmentForm");

assignmentForm.addEventListener("submit", function (e) {

    e.preventDefault();

    const title = document.getElementById("assignmentTitle").value;

    const date = document.getElementById("assignmentDate").value;

    assignments.push({
        id: generateId(),
        title: title,
        date: date,
        completed: false
    });

    saveData("assignments", assignments);

    displayAssignments();

    assignmentForm.reset();

});

function displayAssignments() {

    const list = document.getElementById("assignmentList");

    list.innerHTML = assignments.map(item => `
        <div class="assignment-item">

            <span>
                ${escapeHTML(item.title)}
                <br>
                <small>Due Date: ${escapeHTML(item.date)}</small>
            </span>

            <button data-action="assignment-done"
                data-id="${item.id}">
                ${item.completed ? "Undo" : "Complete"}
            </button>

            <button data-action="assignment-delete"
                data-id="${item.id}">
                Delete
            </button>

        </div>
    `).join("");

    document.getElementById("assignmentCount")
        .textContent = assignments.filter(a => !a.completed).length;

}


/* =================================
   6. EXAMINATION & RESULTS
================================= */

const resultData = [
    { subject: "Java Programming", total: 100, marks: 88, grade: "A" },
    { subject: "Web Technology", total: 100, marks: 85, grade: "A" },
    { subject: "AI & ML", total: 100, marks: 91, grade: "A+" },
    { subject: "Internet of Things", total: 100, marks: 82, grade: "A" },
    { subject: "OOAD", total: 100, marks: 86, grade: "A" }
];

function displayResults() {

    const resultList = document.getElementById("resultList");

    resultList.innerHTML = resultData.map(item => `
        <tr>
            <td>${escapeHTML(item.subject)}</td>
            <td>${item.total}</td>
            <td>${item.marks}</td>
            <td>${item.grade}</td>
        </tr>
    `).join("");

}


/* =================================
   7. STUDY MATERIALS
================================= */

let materials = getData("studyMaterials", []);

document.getElementById("materialForm")
.addEventListener("submit", function (e) {

    e.preventDefault();

    const title = document.getElementById("materialTitle").value;

    const link = document.getElementById("materialLink").value;

    try {
        const url = new URL(link);

        if (!["http:", "https:"].includes(url.protocol)) {
            alert("Please enter a valid website link.");
            return;
        }

        materials.push({
            id: generateId(),
            title: title,
            link: url.href
        });

        saveData("studyMaterials", materials);

        displayMaterials();

        this.reset();

    } catch {
        alert("Please enter a valid URL.");
    }

});


function displayMaterials() {

    const list = document.getElementById("materialList");

    list.innerHTML = materials.map(item => `
        <div class="material-item">

            <strong>${escapeHTML(item.title)}</strong>

            <a href="${escapeHTML(item.link)}"
                target="_blank"
                rel="noopener noreferrer">
                Open Material
            </a>

            <button data-action="material-delete"
                data-id="${item.id}">
                Delete
            </button>

        </div>
    `).join("");

    document.getElementById("materialCount")
        .textContent = materials.length;

}


/* =================================
   8. TO-DO LIST
================================= */

let tasks = getData("todoTasks", []);

document.getElementById("todoForm")
.addEventListener("submit", function (e) {

    e.preventDefault();

    const input = document.getElementById("todoInput");

    tasks.push({
        id: generateId(),
        text: input.value,
        completed: false
    });

    saveData("todoTasks", tasks);

    displayTasks();

    this.reset();

});


function displayTasks() {

    const list = document.getElementById("todoList");

    list.innerHTML = tasks.map(item => `
        <li style="${item.completed ? 'text-decoration:line-through;opacity:0.6;' : ''}">

            ${escapeHTML(item.text)}

            <button data-action="task-done"
                data-id="${item.id}">
                ${item.completed ? "Undo" : "Done"}
            </button>

            <button data-action="task-delete"
                data-id="${item.id}">
                Delete
            </button>

        </li>
    `).join("");

    document.getElementById("taskCount")
        .textContent = tasks.filter(t => !t.completed).length;

}


/* =================================
   9. PERSONAL NOTES
================================= */

let notes = getData("studentNotes", []);

document.getElementById("noteForm")
.addEventListener("submit", function (e) {

    e.preventDefault();

    const title = document.getElementById("noteTitle").value;

    const content = document.getElementById("noteContent").value;

    notes.push({
        id: generateId(),
        title: title,
        content: content
    });

    saveData("studentNotes", notes);

    displayNotes();

    this.reset();

});


function displayNotes() {

    const list = document.getElementById("noteList");

    list.innerHTML = notes.map(item => `
        <div class="note-item">

            <h3>${escapeHTML(item.title)}</h3>

            <p>${escapeHTML(item.content)}</p>

            <button data-action="note-delete"
                data-id="${item.id}">
                Delete Note
            </button>

        </div>
    `).join("");

}


/* =================================
   10. CALENDAR & ANNOUNCEMENTS
================================= */

let announcements = getData("announcements", []);

document.getElementById("announcementForm")
.addEventListener("submit", function (e) {

    e.preventDefault();

    const title = document.getElementById("announcementTitle").value;

    const date = document.getElementById("announcementDate").value;

    announcements.push({
        id: generateId(),
        title: title,
        date: date
    });

    saveData("announcements", announcements);

    displayAnnouncements();

    this.reset();

});


function displayAnnouncements() {

    const list = document.getElementById("announcementList");

    list.innerHTML = announcements.map(item => `
        <div class="announcement-item">

            <strong>${escapeHTML(item.title)}</strong>

            <p>Date: ${escapeHTML(item.date)}</p>

            <button data-action="announcement-delete"
                data-id="${item.id}">
                Delete
            </button>

        </div>
    `).join("");

}


/* =================================
   11. DELETE & COMPLETE FUNCTIONS
================================= */

document.addEventListener("click", function (e) {

    const button = e.target.closest("[data-action]");

    if (!button) return;

    const id = Number(button.dataset.id);

    const action = button.dataset.action;

    if (action === "assignment-delete") {

        assignments = assignments.filter(item => item.id !== id);

        saveData("assignments", assignments);

        displayAssignments();

    }

    else if (action === "assignment-done") {

        assignments = assignments.map(item =>
            item.id === id
                ? { ...item, completed: !item.completed }
                : item
        );

        saveData("assignments", assignments);

        displayAssignments();

    }

    else if (action === "task-delete") {

        tasks = tasks.filter(item => item.id !== id);

        saveData("todoTasks", tasks);

        displayTasks();

    }

    else if (action === "task-done") {

        tasks = tasks.map(item =>
            item.id === id
                ? { ...item, completed: !item.completed }
                : item
        );

        saveData("todoTasks", tasks);

        displayTasks();

    }

    else if (action === "material-delete") {

        materials = materials.filter(item => item.id !== id);

        saveData("studyMaterials", materials);

        displayMaterials();

    }

    else if (action === "note-delete") {

        notes = notes.filter(item => item.id !== id);

        saveData("studentNotes", notes);

        displayNotes();

    }

    else if (action === "announcement-delete") {

        announcements = announcements.filter(item => item.id !== id);

        saveData("announcements", announcements);

        displayAnnouncements();

    }

});


/* =================================
   12. DARK MODE
================================= */

const darkModeBtn = document.getElementById("darkModeBtn");

// Check saved theme
if (localStorage.getItem("darkMode") === "enabled") {

    document.body.classList.add("dark-mode");

    darkModeBtn.textContent = "Light Mode";

}

// Toggle dark mode
darkModeBtn.addEventListener("click", function () {

    document.body.classList.toggle("dark-mode");

    if (document.body.classList.contains("dark-mode")) {

        localStorage.setItem("darkMode", "enabled");

        darkModeBtn.textContent = "Light Mode";

    } else {

        localStorage.setItem("darkMode", "disabled");

        darkModeBtn.textContent = "Dark Mode";

    }

});


/* =================================
   13. LOAD ALL DATA
================================= */

// Display saved data when page loads

function loadDashboard() {

    displayProfile();

    displayAttendance();

    displayTimetable();

    displayAssignments();

    displayResults();

    displayMaterials();

    displayTasks();

    displayNotes();

    displayAnnouncements();

}

// Run dashboard
loadDashboard();
